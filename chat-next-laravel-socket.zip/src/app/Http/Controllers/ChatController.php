<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\User;
use App\Events\MessageSent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatController extends Controller
{
    // ارسال پیام جدید
    public function sendMessage(Request $request)
    {
        $request->validate([
            'receiver_id' => 'required|exists:users,id',
            'message' => 'required|string|max:1000'
        ]);

        $message = Message::create([
            'sender_id' => Auth::id(),
            'receiver_id' => $request->receiver_id,
            'message' => $request->message,
            'is_read' => false,
        ]);

        // بارگذاری رابطه sender برای دسترسی به name
        $message->load('sender');

        // پخش رویداد
        broadcast(new MessageSent($message))->toOthers();

        return response()->json([
            'success' => true,
            'message' => $message
        ]);
    }

    // گرفتن تاریخچه پیام‌ها بین دو کاربر
    public function getMessages($userId)
    {
        $messages = Message::where(function($query) use ($userId) {
            $query->where('sender_id', Auth::id())
                ->where('receiver_id', $userId);
        })->orWhere(function($query) use ($userId) {
            $query->where('sender_id', $userId)
                ->where('receiver_id', Auth::id());
        })->with('sender')->orderBy('created_at', 'asc')->get();

        return response()->json($messages);
    }

    // گرفتن لیست کاربران (برای ادمین)
    public function getUsers()
    {
        $users = User::where('id', '!=', Auth::id())
            ->select('id', 'name', 'email', 'is_admin')
            ->get();

        // اضافه کردن آخرین پیام و تعداد پیام‌های نخوانده
        foreach ($users as $user) {
            $lastMessage = Message::where(function($query) use ($user) {
                $query->where('sender_id', Auth::id())->where('receiver_id', $user->id);
            })->orWhere(function($query) use ($user) {
                $query->where('sender_id', $user->id)->where('receiver_id', Auth::id());
            })->latest()->first();

            $user->last_message = $lastMessage?->message;
            $user->last_message_time = $lastMessage?->created_at;

            $user->unread_count = Message::where('sender_id', $user->id)
                ->where('receiver_id', Auth::id())
                ->where('is_read', false)
                ->count();
        }

        return response()->json($users);
    }

    // علامت زدن پیام به عنوان خوانده شده
    public function markAsRead($senderId)
    {
        Message::where('sender_id', $senderId)
            ->where('receiver_id', Auth::id())
            ->where('is_read', false)
            ->update(['is_read' => true]);

        return response()->json(['success' => true]);
    }
}

<?php

use App\Models\User;
use Illuminate\Support\Facades\Broadcast;

Broadcast::channel('chat.{userId}', function (User $user, int $userId) {
    \Log::info('Channel auth attempt', [
        'user_id' => $user->id,
        'requested_user_id' => $userId,
        'is_admin' => $user->is_admin
    ]);

    if ($user->id === $userId) {
        return ['id' => $user->id, 'name' => $user->name];
    }

    if ($user->is_admin) {
        return ['id' => $user->id, 'name' => $user->name, 'is_admin' => true];
    }

    return false;
});

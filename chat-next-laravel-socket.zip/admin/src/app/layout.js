'use client';

import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import './globals.css';

export default function RootLayout({ children }) {
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        const token = localStorage.getItem('token');

        if (!token && pathname !== '/login') {
            router.push('/login');
        }
    }, [pathname, router]);

    return (
        <html lang="fa" dir="rtl">
        <body>{children}</body>
        </html>
    );
}
// admin/src/app/page.js
'use client';

import React, { useState, useEffect } from 'react';
import { useAdminChat } from './lib/hooks/useAdminChat';

export default function AdminPage() {
    const {
        activeChats,
        activeUserId,
        setActiveUserId,
        sendToUser,
        users,
        isConnected,
        loadChatHistory,
    } = useAdminChat();

    const [message, setMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        if (activeUserId) {
            loadChatHistory(activeUserId);
        }
    }, [activeUserId]);

    const handleSendMessage = async () => {
        if (!message.trim() || !activeUserId) return;
        await sendToUser(activeUserId, message);
        setMessage('');
    };

    // تابع فرمت تاریخ
    const formatTime = (dateString) => {
        if (!dateString) return '';
        try {
            const date = new Date(dateString);
            if (isNaN(date.getTime())) return '';
            return date.toLocaleTimeString('fa-IR', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });
        } catch {
            return '';
        }
    };

    const filteredUsers = users.filter(
        (user) =>
            user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div style={{ display: 'flex', height: '100vh', fontFamily: 'sans-serif' }}>
            <div style={{ width: '33%', borderRight: '1px solid #ccc', background: '#f9f9f9' }}>
                <div style={{ padding: '1rem', borderBottom: '1px solid #ccc' }}>
                    <h2>کاربران چت</h2>
                    <input
                        type="text"
                        placeholder="جستجو..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }}
                    />
                    <div style={{ marginTop: '0.5rem', fontSize: '0.8rem' }}>
                        وضعیت: {isConnected ? '🟢 متصل' : '🔴 قطع'}
                    </div>
                </div>
                <div style={{ overflowY: 'auto', height: 'calc(100vh - 120px)' }}>
                    {filteredUsers.map((user) => (
                        <div
                            key={user.id}
                            onClick={() => setActiveUserId(user.id)}
                            style={{
                                padding: '1rem',
                                borderBottom: '1px solid #eee',
                                cursor: 'pointer',
                                background: activeUserId === user.id ? '#e0e7ff' : 'transparent',
                            }}
                        >
                            <h3>{user.name}</h3>
                            <p style={{ fontSize: '0.8rem', color: '#555' }}>{user.email}</p>
                        </div>
                    ))}
                </div>
            </div>

            <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                {activeUserId ? (
                    <>
                        <div style={{ padding: '1rem', borderBottom: '1px solid #ccc', background: '#fff' }}>
                            <h3>{users.find((u) => u.id === activeUserId)?.name || 'کاربر'}</h3>
                        </div>
                        <div style={{ flex: 1, overflowY: 'auto', padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            {activeChats[activeUserId]?.messages?.map((msg, idx) => (
                                <div key={idx} style={{ display: 'flex', justifyContent: msg.isFromUser ? 'flex-start' : 'flex-end' }}>
                                    <div style={{
                                        maxWidth: '70%',
                                        padding: '0.5rem',
                                        borderRadius: '8px',
                                        background: msg.isFromUser ? '#f1f1f1' : '#007bff',
                                        color: msg.isFromUser ? '#000' : '#fff',
                                    }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                                            <p style={{ fontSize: '0.7rem', fontWeight: 'bold', margin: 0 }}>{msg.senderName}</p>
                                            <p style={{ fontSize: '0.6rem', opacity: 0.7, margin: 0 }}>
                                                {formatTime(msg.time)}
                                            </p>
                                        </div>
                                        <p style={{ margin: 0 }}>{msg.text}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div style={{ padding: '1rem', borderTop: '1px solid #ccc', background: '#fff' }}>
                            <div style={{ display: 'flex', gap: '8px' }}>
                                <input
                                    type="text"
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                                    placeholder="پیام خود را بنویسید..."
                                    style={{ flex: 1, padding: '0.5rem' }}
                                />
                                <button onClick={handleSendMessage} style={{ padding: '0.5rem 1rem', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
                                    ارسال
                                </button>
                            </div>
                        </div>
                    </>
                ) : (
                    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#888' }}>
                        برای شروع چت، یک کاربر را انتخاب کنید
                    </div>
                )}
            </div>
        </div>
    );
}
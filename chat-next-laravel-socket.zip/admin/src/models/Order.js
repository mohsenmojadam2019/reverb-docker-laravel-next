import mongoose from 'mongoose';

const OrderSchema = new mongoose.Schema({
    user: {
        name: { type: String, required: true },
        email: { type: String, required: true },
        country: String,
        city: { type: String, required: true },
        address: { type: String, required: true },
        postalCode: String,
    },
    cart: [{
        _id: String,
        title: String,
        price: Number,
        quantity: Number,
        image: String,
    }],
    totalPrice: { type: Number, required: true },
    status: {
        type: String,
        default: "pending",
        enum: ["pending", "paid", "shipped", "delivered", "cancelled"]
    },
    createdAt: {  // ← اصلاح: createdAt (با حرف t بزرگ)
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});
export default mongoose.models.Order || mongoose.model('Order', OrderSchema);
// models/User.js
import mongoose from 'mongoose';

const UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'نام الزامی است'],
        trim: true,
        minlength: [2, 'نام حداقل ۲ کاراکتر باید باشد'],
        maxlength: [50, 'نام حداکثر ۵۰ کاراکتر می‌تواند باشد']
    },
    family: {
        type: String,
        required: [true, 'نام خانوادگی الزامی است'],
        trim: true,
        minlength: [2, 'نام خانوادگی حداقل ۲ کاراکتر باید باشد'],
        maxlength: [50, 'نام خانوادگی حداکثر ۵۰ کاراکتر می‌تواند باشد']
    },
    email: {
        type: String,
        required: [true, 'ایمیل الزامی است'],
        unique: true,
        trim: true,
        lowercase: true,
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'ایمیل نامعتبر است']
    },
    mobile: {
        type: String,
        required: [true, 'شماره موبایل الزامی است'],
        unique: true,
        trim: true,
        match: [/^09[0-9]{9}$/, 'شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود']
    },
    image: {
        type: String,
        default: '/images/default-avatar.png',  // عکس پیش‌فرض
        // حذف validation تا اجباری نباشه
    },
    password: {
        type: String,
        required: [true, 'رمز عبور الزامی است'],
        minlength: [6, 'رمز عبور حداقل ۶ کاراکتر باید باشد']
    },
    role: {
        type: String,
        enum: ['user', 'admin', 'moderator'],
        default: 'user'
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    lastLogin: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Virtual: نام کامل
UserSchema.virtual('fullName').get(function() {
    return `${this.name} ${this.family}`;
});

// Virtual: آیا پروفایل کامل است؟
UserSchema.virtual('isProfileComplete').get(function() {
    return !!(this.name && this.family && this.email && this.mobile);
});

// متد: بررسی رمز عبور
UserSchema.methods.comparePassword = async function(candidatePassword) {
    const bcrypt = await import('bcryptjs');
    return await bcrypt.default.compare(candidatePassword, this.password);
};

// متد: به‌روزرسانی زمان آخرین ورود
UserSchema.methods.updateLastLogin = function() {
    this.lastLogin = new Date();
    return this.save();
};

export default mongoose.models.User || mongoose.model('User', UserSchema);
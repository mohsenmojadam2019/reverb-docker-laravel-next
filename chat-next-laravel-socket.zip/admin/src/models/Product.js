// models/Product.js
import mongoose from 'mongoose';

const ProductSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'عنوان محصول الزامی است'],
        trim: true,
        minlength: [3, 'عنوان حداقل ۳ کاراکتر باید باشد'],
        maxlength: [100, 'عنوان حداکثر ۱۰۰ کاراکتر می‌تواند باشد']
    },
    price: {
        type: Number,
        required: [true, 'قیمت محصول الزامی است'],
        min: [1000, 'قیمت حداقل ۱۰۰۰ تومان باید باشد'],
        max: [1000000000, 'قیمت حداکثر ۱ میلیارد تومان می‌تواند باشد']
    },
    image: {
        type: String,
        default: '/images/default.jpg',
        validate: {
            validator: function(v) {
                return /\.(jpg|jpeg|png|webp)$/i.test(v);
            },
            message: 'فرمت عکس باید jpg, jpeg, png یا webp باشد'
        }
    },
    category: {
        type: String,
        required: true,
    },
    stock: {
        type: Number,
        required: true,
        default: 0,
        min: [0, 'موجودی نمی‌تواند منفی باشد'],
        max: [1000, 'موجودی حداکثر ۱۰۰۰ عدد می‌تواند باشد']
    }
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

ProductSchema.virtual('inStock').get(function() {
    return this.stock > 0;
});

ProductSchema.methods.applyDiscount = function(percent) {
    this.price = this.price * (100 - percent) / 100;
    return this.price;
};

export default mongoose.models.Product || mongoose.model('Product', ProductSchema);
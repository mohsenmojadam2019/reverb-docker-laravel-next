// components/ImageUpload.js
"use client";
import { useState } from 'react';
import Image from 'next/image';

export default function ImageUpload({ onImageUpload, currentImage }) {
    const [preview, setPreview] = useState(currentImage || null);
    const [uploading, setUploading] = useState(false);
    const [error, setError] = useState('');

    async function handleFileChange(e) {
        const file = e.target.files[0];
        if (!file) return;

        // نمایش پیش‌نمایش
        const reader = new FileReader();
        reader.onloadend = () => {
            setPreview(reader.result);
        };
        reader.readAsDataURL(file);

        // آپلود به سرور
        setUploading(true);
        setError('');

        try {
            const formData = new FormData();
            formData.append('image', file);

            const res = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            const data = await res.json();

            if (res.ok) {
                onImageUpload(data.url);
            } else {
                setError(data.error);
                setPreview(currentImage);
            }
        } catch (err) {
            setError('خطا در آپلود');
            setPreview(currentImage);
        } finally {
            setUploading(false);
        }
    }

    return (
        <div style={styles.container}>
            <div style={styles.previewContainer}>
                {preview ? (
                    <div style={styles.preview}>
                        <img src={preview} alt="پیش‌نمایش" style={styles.image} />
                        <button
                            type="button"
                            onClick={() => {
                                setPreview(null);
                                onImageUpload('');
                            }}
                            style={styles.removeBtn}
                        >
                            ✖
                        </button>
                    </div>
                ) : (
                    <div style={styles.placeholder}>
                        📷 بدون عکس
                    </div>
                )}
            </div>

            <label style={styles.uploadBtn}>
                {uploading ? 'در حال آپلود...' : 'انتخاب عکس'}
                <input
                    type="file"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    onChange={handleFileChange}
                    disabled={uploading}
                    style={styles.hiddenInput}
                />
            </label>

            {error && <div style={styles.error}>{error}</div>}
        </div>
    );
}

const styles = {
    container: {
        marginBottom: '16px',
    },
    previewContainer: {
        marginBottom: '10px',
    },
    preview: {
        position: 'relative',
        width: '120px',
        height: '120px',
        borderRadius: '50%',
        overflow: 'hidden',
        border: '2px solid #ddd',
    },
    image: {
        width: '100%',
        height: '100%',
        objectFit: 'cover',
    },
    removeBtn: {
        position: 'absolute',
        top: '5px',
        right: '5px',
        background: 'red',
        color: 'white',
        border: 'none',
        borderRadius: '50%',
        width: '25px',
        height: '25px',
        cursor: 'pointer',
        fontSize: '12px',
    },
    placeholder: {
        width: '120px',
        height: '120px',
        borderRadius: '50%',
        background: '#f0f0f0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '30px',
        border: '2px solid #ddd',
    },
    uploadBtn: {
        display: 'inline-block',
        background: '#3b82f6',
        color: 'white',
        padding: '8px 16px',
        borderRadius: '8px',
        cursor: 'pointer',
        fontSize: '14px',
        textAlign: 'center',
    },
    hiddenInput: {
        display: 'none',
    },
    error: {
        color: 'red',
        fontSize: '12px',
        marginTop: '8px',
    },
};
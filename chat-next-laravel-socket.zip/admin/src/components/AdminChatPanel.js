// admin/src/components/AdminChatPanel.js
'use client';

import React, { useState, useEffect } from 'react';
import { useAdminChat } from '@/lib/hooks/useAdminChat';

export default function AdminChatPanel() {
    const {
        activeChats,
        activeUserId,
        setActiveUserId,
        sendToUser,
        users,
        isConnected,
        loadChatHistory,
    } = useAdminChat();

    const [message, setMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        if (activeUserId) {
            loadChatHistory(activeUserId);
        }
    }, [activeUserId]);

    const handleSendMessage = async () => {
        if (!message.trim() || !activeUserId) return;
        await sendToUser(activeUserId, message);
        setMessage('');
    };

    const filteredUsers = users.filter(
        (user) =>
            user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div style={{ display: 'flex', height: '100vh' }}>
            {/* لیست کاربران */}
            <div
                style={{
                    width: '33%',
                    borderRight: '1px solid #e5e7eb',
                    backgroundColor: '#f9fafb',
                }}
            >
                <div style={{ padding: '1rem', borderBottom: '1px solid #e5e7eb' }}>
                    <h2 style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>
                        کاربران چت
                    </h2>
                    <input
                        type="text"
                        placeholder="جستجوی کاربر..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        style={{
                            marginTop: '0.5rem',
                            width: '100%',
                            padding: '0.5rem',
                            border: '1px solid #d1d5db',
                            borderRadius: '0.25rem',
                        }}
                    />
                    <div style={{ marginTop: '0.5rem', fontSize: '0.875rem' }}>
                        وضعیت: {isConnected ? '🟢 متصل' : '🔴 قطع'}
                    </div>
                </div>
                <div style={{ overflowY: 'auto', height: 'calc(100vh - 120px)' }}>
                    {filteredUsers.map((user) => (
                        <div
                            key={user.id}
                            onClick={() => setActiveUserId(user.id)}
                            style={{
                                padding: '1rem',
                                borderBottom: '1px solid #e5e7eb',
                                cursor: 'pointer',
                                backgroundColor:
                                    activeUserId === user.id ? '#eff6ff' : 'transparent',
                                transition: 'background-color 0.2s',
                            }}
                        >
                            <h3 style={{ fontWeight: 'bold' }}>{user.name}</h3>
                            <p style={{ fontSize: '0.875rem', color: '#4b5563' }}>
                                {user.email}
                            </p>
                            {activeChats[user.id]?.messages?.slice(-1)[0] && (
                                <p
                                    style={{
                                        fontSize: '0.875rem',
                                        color: '#6b7280',
                                        marginTop: '0.25rem',
                                        whiteSpace: 'nowrap',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                    }}
                                >
                                    {activeChats[user.id].messages.slice(-1)[0].text}
                                </p>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {/* پنجره چت */}
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                {activeUserId ? (
                    <>
                        <div
                            style={{
                                padding: '1rem',
                                borderBottom: '1px solid #e5e7eb',
                                backgroundColor: 'white',
                            }}
                        >
                            <h2 style={{ fontWeight: 'bold' }}>
                                {users.find((u) => u.id === activeUserId)?.name || 'کاربر'}
                            </h2>
                        </div>
                        <div
                            style={{
                                flex: 1,
                                overflowY: 'auto',
                                padding: '1rem',
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '0.75rem',
                            }}
                        >
                            {activeChats[activeUserId]?.messages?.map((msg, idx) => (
                                <div
                                    key={idx}
                                    style={{
                                        display: 'flex',
                                        justifyContent: msg.isFromUser ? 'flex-start' : 'flex-end',
                                    }}
                                >
                                    <div
                                        style={{
                                            maxWidth: '70%',
                                            padding: '0.75rem',
                                            borderRadius: '0.5rem',
                                            backgroundColor: msg.isFromUser ? '#e5e7eb' : '#3b82f6',
                                            color: msg.isFromUser ? '#1f2937' : 'white',
                                        }}
                                    >
                                        <p style={{ fontSize: '0.875rem', fontWeight: 'bold' }}>
                                            {msg.senderName}
                                        </p>
                                        <p>{msg.text}</p>
                                        <p
                                            style={{
                                                fontSize: '0.7rem',
                                                marginTop: '0.25rem',
                                                opacity: 0.75,
                                            }}
                                        >
                                            {new Date(msg.time).toLocaleTimeString()}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div style={{ padding: '1rem', borderTop: '1px solid #e5e7eb' }}>
                            <div style={{ display: 'flex', gap: '0.5rem' }}>
                                <input
                                    type="text"
                                    value={message}
                                    onChange={(e) => setMessage(e.target.value)}
                                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                                    placeholder="پیام خود را بنویسید..."
                                    style={{
                                        flex: 1,
                                        padding: '0.5rem',
                                        border: '1px solid #d1d5db',
                                        borderRadius: '0.25rem',
                                    }}
                                />
                                <button
                                    onClick={handleSendMessage}
                                    style={{
                                        padding: '0.5rem 1rem',
                                        backgroundColor: '#3b82f6',
                                        color: 'white',
                                        border: 'none',
                                        borderRadius: '0.25rem',
                                        cursor: 'pointer',
                                    }}
                                >
                                    ارسال
                                </button>
                            </div>
                        </div>
                    </>
                ) : (
                    <div
                        style={{
                            flex: 1,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#6b7280',
                        }}
                    >
                        برای شروع چت، یک کاربر را انتخاب کنید
                    </div>
                )}
            </div>
        </div>
    );
}
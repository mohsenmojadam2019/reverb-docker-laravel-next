// src/components/Sidebar.js
"use client";
import { FiHome, FiBox, FiShoppingCart, FiUsers } from "react-icons/fi";
import Link from "next/link";
import { usePathname } from "next/navigation";

const Sidebar = () => {
    const pathname = usePathname();

    const menuItems = [
        { href: "/", icon: <FiHome />, label: "داشبورد" },
        { href: "/products", icon: <FiBox />, label: "محصولات" },
        { href: "/orders", icon: <FiShoppingCart />, label: "سفارشات" },
        { href: "/users", icon: <FiUsers />, label: "کاربران" },
    ];

    return (
        <div className="sidebar">
            <div className="sidebar-header">
                🛍️ پنل مدیریت
            </div>
            {menuItems.map((item) => (
                <Link
                    key={item.href}
                    href={item.href}
                    className={`link ${pathname === item.href ? "active" : ""}`}
                >
                    {item.icon}
                    <span>{item.label}</span>
                </Link>
            ))}
        </div>
    );
};

export default Sidebar;
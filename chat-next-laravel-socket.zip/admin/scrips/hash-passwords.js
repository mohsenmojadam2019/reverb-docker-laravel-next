// admin/scripts/hash-passwords.js
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");

const MONGODB_URI = "mongodb://localhost:27017/shop_db";

async function hashPasswords() {
    await mongoose.connect(MONGODB_URI);

    // مدل User رو import کن
    const User = mongoose.models.User;
    const users = await User.find({});

    for (const user of users) {
        if (user.password && !user.password.startsWith("$2")) {
            const hashedPassword = await bcrypt.hash(user.password, 10);
            user.password = hashedPassword;
            await user.save();
            console.log(`✅ پسورد برای ${user.email} هش شد`);
        }
    }

    console.log("✅ تمام پسوردها هش شدند!");
    process.exit();
}

hashPasswords();
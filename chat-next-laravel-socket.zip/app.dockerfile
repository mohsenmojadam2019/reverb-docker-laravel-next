FROM php:8.3-fpm
WORKDIR /var/www

RUN sed -i 's|deb.debian.org|linux-mirror.liara.ir/repository|g' /etc/apt/sources.list.d/debian.sources

RUN apt-get -o Acquire::Check-Valid-Until=false update && \
    apt-get install -y \
    openssl zip unzip git curl \
    libzip-dev libonig-dev libicu-dev \
    autoconf pkg-config supervisor \
    libexif-dev libfreetype6-dev libjpeg62-turbo-dev libpng-dev && \
    docker-php-ext-configure pcntl --enable-pcntl && \
    docker-php-ext-install pcntl exif && \
    docker-php-ext-configure gd --with-freetype --with-jpeg && \
    docker-php-ext-install gd zip bcmath mbstring intl opcache pdo pdo_mysql mysqli sockets && \
    mkdir -p /usr/src/php/ext/redis && \
    curl -L https://github.com/phpredis/phpredis/archive/5.3.4.tar.gz | tar xvz -C /usr/src/php/ext/redis --strip 1 && \
    docker-php-ext-install redis

# نصب کامپوزر
COPY --from=composer:latest /usr/bin/composer /usr/bin/composer

# کپی composer.json ابتدا (برای کش بهتر)
COPY ./src/composer.json /var/www/
COPY ./src/composer.lock /var/www/ 2>/dev/null || true

# تنظیم میرور کامپوزر لیارا
RUN composer config -g repos.packagist composer https://package-mirror.liara.ir/repository/composer/

# نصب وابستگی‌ها
RUN cd /var/www && composer install --ignore-platform-reqs --no-interaction

# کپی بقیه فایل‌ها
COPY ./src /var/www

# اجرای اسکریپت‌های کامپوزر
RUN cd /var/www && composer run-script post-autoload-dump || true

COPY ./supervisor/supervisord.conf /etc/supervisor/conf.d/supervisord.conf
COPY ./php/local.ini /usr/local/etc/php/conf.d/local.ini

RUN chmod -R 777 storage/ && \
    chown -R www-data:www-data /var/www/storage && \
    chown -R www-data:www-data /var/www/bootstrap/cache

EXPOSE 9000
CMD ["php-fpm", "-y", "/usr/local/etc/php-fpm.conf", "-R"]